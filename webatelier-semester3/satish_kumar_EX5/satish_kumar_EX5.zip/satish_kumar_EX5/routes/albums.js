
var express = require('express')
var router = express.Router()
var mongoose = require('mongoose')

require("../models/Album")
var Album = mongoose.model("Album")
var ObjectId = mongoose.Schema.Types.ObjectId;

router.get("/", function (req, res) {

    Album.find({}, function (err, docs) {
        if (err) throw err

        if (!(req.accepts("application/json"))) {
            res.end()
            
        } else {
            if (!docs) res.status(404)
            res.json(docs);
        }

    })

})

router.get("/:id", function (req, res) {

    Album.findById(req.params.id, function (err, doc) {
        if (err) throw err;

        if (!(req.accepts("application/json"))) {
            res.end()
            
        } else {
            if (!docs) res.status(404)
            res.json(docs);
        }
    })

})

router.delete("/:id", function (req, res) {

    Album.findByIdAndRemove(req.params.id, function (err, doc) {
        if (err) throw err;

        if (doc) {
            res.status(204)
            res.end()
            
        } else {
            res.status(404)
            res.end()
        }
    })
})

var bodyValid = function (req) {
    if (!req.body.artist || !req.body.name || !req.body.dateReleased) {
        return false;
    } else {
        return true;
    }
}

router.post("/", function (req, res) {
    if (bodyValid(req)) {
        var album = new Album({
        name: req.body.name,
        artist: req.body.artist,
        artwork: req.body.artwork,
        tracks: req.body.tracks || [],
        dateCreated: req.body.dateCreated || Date.now,
        dateReleased: req.body.dateReleased,
        label: req.body.label
    })
        res.status(201).json(album);
        
    } else {
        res.status(400)
        res.end()
    }
})

router.put("/:id", function (req, res) {

    if (bodyValid(req)) {
        Album.findByIdAndUpdate(req.params.id, req.body, function (err, doc) {
            if (doc) {
                res.status(204)
                res.end()
            } else {
                var newAlbum = new Album({
                name: req.body.name,
                artist: req.body.artist,
                artwork: req.body.artwork,
                tracks: req.body.tracks || [],
                dateCreated: req.body.dateCreated || Date.now,
                dateReleased: req.body.dateReleased,
                label: req.body.label
    })
                newAlbum.save(function (err) {
                    res.status(201).json(newAlbum)
                })
                
            }
        })

    } else {
        res.status(400)
        res.end()
    }

})

module.exports = router;