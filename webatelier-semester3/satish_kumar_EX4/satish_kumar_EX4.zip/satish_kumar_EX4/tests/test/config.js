'use strict';

var path = require('path')
module.exports={
  baseURL : 'http://127.0.0.1:1337',
  projectRoot : path.resolve(__dirname, '../..')
}