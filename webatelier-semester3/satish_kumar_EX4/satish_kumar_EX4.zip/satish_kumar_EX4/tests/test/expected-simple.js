module.exports = {
"Hello" : 3,
"my" : 1,
"name" : 1,
"is" : 1,
"vassilis" : 1,
"Did" : 2,
"I" : 2,
"say" : 1,
"hello" : 1,
"then" : 1
}
