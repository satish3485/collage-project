/*
    TimelineJS - ver. 2.34.1 - 2014-10-29
    Copyright (c) 2012-2013 Northwestern University
    a project of the Northwestern University Knight Lab, originally created by Zach Wise
    https://github.com/NUKnightLab/TimelineJS
    This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
    If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
*/
if(typeof VMM!="undefined"){VMM.Language={lang:"tl",api:{wikipedia:"tl"},date:{month:["Enemo","Pebrero","Marso","Abril","Mayo","Hunyo","Hulyo","Agosto","Setyembre","Oktubre","Nobyembre","Disyembre"],month_abbr:["Ene.","Peb.","Mar.","Abr.","Mayo","Hun.","Hul.","Ago.","Set.","Okt.","Nob.","Dis."],day:["Linggo","Lunes","Martes","Miyerkules","Huwebes","Biyernes","Sabado"],day_abbr:["Li.","L.","M.","Mi.","H.","B.","S."]},dateformats:{year:"yyyy",month_short:"mmm",month:"mmmm yyyy",full_short:"mmm d",full:"mmmm d',' yyyy",time_short:"h:MM:ss TT",time_no_seconds_short:"h:MM TT",time_no_seconds_small_date:"h:MM TT'<br/><small>'mmmm d',' yyyy'</small>'",full_long:"mmm d',' yyyy 'at' h:MM TT",full_long_small_date:"h:MM TT'<br/><small>mmm d',' yyyy'</small>'"},messages:{loading_timeline:"Loading Timeline... ",return_to_title:"Return to Title",expand_timeline:"Expand Timeline",contract_timeline:"Contract Timeline",wikipedia:"Mula sa Wikipedia, ang malayang ensiklopedya",loading_content:"Loading Content",loading:"Loading"}}}